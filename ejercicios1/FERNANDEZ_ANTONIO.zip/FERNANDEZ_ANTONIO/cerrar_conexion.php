<?php

function close_conn($conn){
  mysqli_close($conn);
}

 ?>
